import Link from 'next/link'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, Clock, CreditCard, Users, Zap } from 'lucide-react'

export default function TenantPricing() {
  return (
    <div className="flex flex-col min-h-screen bg-[#F1FAEE]">
      <main className="flex-grow container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8 text-[#1D3557] text-center">Tenant Pricing Plans</h1>

        <Tabs defaultValue="ongoing" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="ongoing">Ongoing Reporting</TabsTrigger>
            <TabsTrigger value="past">Past Reporting</TabsTrigger>
          </TabsList>
          <TabsContent value="ongoing">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Monthly Plan</CardTitle>
                  <CardDescription>Flexible month-to-month reporting</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold">$5.95<span className="text-xl font-normal">/month</span></p>
                  <ul className="mt-4 space-y-2">
                    <li className="flex items-center"><CheckCircle className="mr-2 h-5 w-5 text-green-500" /> Reports current rent payments</li>
                    <li className="flex items-center"><CheckCircle className="mr-2 h-5 w-5 text-green-500" /> TransUnion and Experian reporting</li>
                    <li className="flex items-center"><CheckCircle className="mr-2 h-5 w-5 text-green-500" /> No credit inquiry required</li>
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button className="w-full bg-[#1D3557] text-white hover:bg-[#457B9D]">Choose Plan</Button>
                </CardFooter>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Annual Plan</CardTitle>
                  <CardDescription>Save with our yearly subscription</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold">$59.00<span className="text-xl font-normal">/year</span></p>
                  <p className="text-sm text-muted-foreground">Equivalent to $4.92/month</p>
                  <ul className="mt-4 space-y-2">
                    <li className="flex items-center"><CheckCircle className="mr-2 h-5 w-5 text-green-500" /> All Monthly Plan features</li>
                    <li className="flex items-center"><CheckCircle className="mr-2 h-5 w-5 text-green-500" /> Save over 17% compared to monthly</li>
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button className="w-full bg-[#1D3557] text-white hover:bg-[#457B9D]">Choose Plan</Button>
                </CardFooter>
              </Card>
            </div>
          </TabsContent>
          <TabsContent value="past">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>12-Month History</CardTitle>
                  <CardDescription>Report your past year of rent payments</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold">$39.00<span className="text-xl font-normal"> one-time fee</span></p>
                  <ul className="mt-4 space-y-2">
                    <li className="flex items-center"><CheckCircle className="mr-2 h-5 w-5 text-green-500" /> Reports past 12 months of rent</li>
                    <li className="flex items-center"><CheckCircle className="mr-2 h-5 w-5 text-green-500" /> Avg. 20-60 point score increase</li>
                    <li className="flex items-center"><Clock className="mr-2 h-5 w-5 text-blue-500" /> Results in about two weeks</li>
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button className="w-full bg-[#1D3557] text-white hover:bg-[#457B9D]">Choose Plan</Button>
                </CardFooter>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>24-Month History</CardTitle>
                  <CardDescription>Maximize impact with two years of history</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold">$55.00<span className="text-xl font-normal"> one-time fee</span></p>
                  <ul className="mt-4 space-y-2">
                    <li className="flex items-center"><CheckCircle className="mr-2 h-5 w-5 text-green-500" /> Reports past 24 months of rent</li>
                    <li className="flex items-center"><CheckCircle className="mr-2 h-5 w-5 text-green-500" /> Avg. 30-100 point score increase</li>
                    <li className="flex items-center"><Clock className="mr-2 h-5 w-5 text-blue-500" /> Results in about two weeks</li>
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button className="w-full bg-[#1D3557] text-white hover:bg-[#457B9D]">Choose Plan</Button>
                </CardFooter>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        <section className="mt-12">
          <h2 className="text-2xl font-semibold mb-4 text-[#1D3557]">Combined Past and Ongoing Reporting</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>12-Month History + Ongoing</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold">$39.00 <span className="text-lg font-normal">one-time</span> + $5.95<span className="text-lg font-normal">/month</span></p>
                <ul className="mt-4 space-y-2">
                  <li className="flex items-center"><CheckCircle className="mr-2 h-5 w-5 text-green-500" /> Past 12 months reporting</li>
                  <li className="flex items-center"><CheckCircle className="mr-2 h-5 w-5 text-green-500" /> Ongoing monthly reporting</li>
                  <li className="flex items-center"><CheckCircle className="mr-2 h-5 w-5 text-green-500" /> Significant score improvement potential</li>
                </ul>
              </CardContent>
              <CardFooter>
                <Button className="w-full bg-[#1D3557] text-white hover:bg-[#457B9D]">Choose Plan</Button>
              </CardFooter>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>24-Month History + Ongoing</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold">$55.00 <span className="text-lg font-normal">one-time</span> + $5.95<span className="text-lg font-normal">/month</span></p>
                <ul className="mt-4 space-y-2">
                  <li className="flex items-center"><CheckCircle className="mr-2 h-5 w-5 text-green-500" /> Past 24 months reporting</li>
                  <li className="flex items-center"><CheckCircle className="mr-2 h-5 w-5 text-green-500" /> Ongoing monthly reporting</li>
                  <li className="flex items-center"><CheckCircle className="mr-2 h-5 w-5 text-green-500" /> Maximum score improvement potential</li>
                </ul>
              </CardContent>
              <CardFooter>
                <Button className="w-full bg-[#1D3557] text-white hover:bg-[#457B9D]">Choose Plan</Button>
              </CardFooter>
            </Card>
          </div>
        </section>

        <section className="mt-12">
          <h2 className="text-2xl font-semibold mb-4 text-[#1D3557]">Discounts and Special Offers</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Military Personnel</CardTitle>
              </CardHeader>
              <CardContent>
                <Badge className="bg-[#457B9D] text-white">10% OFF</Badge>
                <p className="mt-2">Valid military ID or proof of service required.</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Low-Income Individuals</CardTitle>
              </CardHeader>
              <CardContent>
                <Badge className="bg-[#457B9D] text-white">10% OFF</Badge>
                <p className="mt-2">Proof of income below specified threshold required.</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Referral Program</CardTitle>
              </CardHeader>
              <CardContent>
                <Badge className="bg-[#457B9D] text-white">$10 CREDIT</Badge>
                <p className="mt-2">For each referred customer who signs up. Up to $50 in credits.</p>
              </CardContent>
            </Card>
          </div>
        </section>

        <section className="mt-12">
          <h2 className="text-2xl font-semibold mb-4 text-[#1D3557]">Additional Services</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Zap className="mr-2 h-5 w-5 text-yellow-500" />
                  Expedited Reporting
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xl font-bold">$75.00 <span className="text-lg font-normal">one-time fee</span></p>
                <p className="mt-2">Ensures rent payment history is reported within three business days after verification.</p>
              </CardContent>
              <CardFooter>
                <Button className="w-full bg-[#1D3557] text-white hover:bg-[#457B9D]">Add Service</Button>
              </CardFooter>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="mr-2 h-5 w-5 text-blue-500" />
                  Roommate/Spouse Addition
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xl font-bold">$20.00 <span className="text-lg font-normal">one-time fee per person</span></p>
                <p className="mt-2">Allows multiple tenants on the same lease to benefit from rent reporting.</p>
              </CardContent>
              <CardFooter>
                <Button className="w-full bg-[#1D3557] text-white hover:bg-[#457B9D]">Add Service</Button>
              </CardFooter>
            </Card>
          </div>
        </section>

        <section className="mt-12">
          <h2 className="text-2xl font-semibold mb-4 text-[#1D3557]">Payment Options</h2>
          <Card>
            <CardContent className="mt-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Flexible Payment Plans</h3>
                  <ul className="space-y-2">
                    <li className="flex items-center"><CheckCircle className="mr-2 h-5 w-5 text-green-500" /> Monthly installments for fees over $50</li>
                    <li className="flex items-center"><CheckCircle className="mr-2 h-5 w-5 text-green-500" /> No interest on 3-month installment plans</li>
                  </ul>
                </div>
                <div>
                  <h3 className="text-lg font-semibold mb-2">Accepted Payment Methods</h3>
                  <ul className="space-y-2">
                    <li className="flex items-center"><CreditCard className="mr-2 h-5 w-5 text-blue-500" /> Credit/Debit Cards</li>
                    <li className="flex items-center"><CreditCard className="mr-2 h-5 w-5 text-blue-500" /> ACH Transfers</li>
                    <li className="flex items-center"><CreditCard className="mr-2 h-5 w-5 text-blue-500" /> Money Orders</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        <section className="mt-12 text-center">
          <h2 className="text-2xl font-semibold mb-4 text-[#1D3557]">Need Help Choosing?</h2>
          <p className="mb-4">Our customer support team is here to assist you in selecting the best plan for your needs.</p>
          <Button className="bg-[#1D3557] text-white hover:bg-[#457B9D]">Contact Support</Button>
        </section>
      </main>
    </div>
  )
}

