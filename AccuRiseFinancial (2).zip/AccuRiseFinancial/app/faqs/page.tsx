import Link from 'next/link'
import { Button } from "@/components/ui/button"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export default function FAQPage() {
  return (
    <div className="flex flex-col min-h-screen bg-[#F1FAEE]">
      <main className="flex-grow container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8 text-[#1D3557] text-center">Frequently Asked Questions for Tenants</h1>

        <Accordion type="single" collapsible className="w-full space-y-4">
          <AccordionItem value="address">
            <AccordionTrigger className="text-lg font-semibold text-[#1D3557]">Address and Reporting</AccordionTrigger>
            <AccordionContent>
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold">Can I report my monthly rent payments if I sublease?</h3>
                  <p>Yes, you can! As long as you have a written agreement with the primary landlord, management company, or owner of the home. We cannot report rent payments if you only have an agreement with the original renter. If you're not on the main lease, you should request to be added.</p>
                </div>
                <div>
                  <h3 className="font-semibold">Who is responsible to let you know if I move?</h3>
                  <p>We count on you and your landlord to keep us informed so that we can ensure accurate reporting to the credit bureaus. If we receive notice from your landlord that you are no longer renting from them, we will reach out to you for confirmation and then close out your account.</p>
                </div>
                <div>
                  <h3 className="font-semibold">Can you report my past addresses?</h3>
                  <p>We are able to report the last 24 months of your past rental history. This helps to add age to your credit profile, which in turn provides a greater increase in your credit score. Upon enrolling and receiving your photo ID and lease agreement (if you have it available - not required), our verification department will reach out to your landlord and confirm all information.</p>
                </div>
                <div>
                  <h3 className="font-semibold">Can I report both my current and previous addresses?</h3>
                  <p>Yes, you can! We can report up to the last 24 months of your past address, and do ongoing monthly reporting for your current address. You would select either the past 12 months or past 24 months of reporting for your previous address, and then also select either the annual payment or the monthly subscription option for the ongoing reporting for your current address.</p>
                </div>
                <div>
                  <h3 className="font-semibold">My photo ID does not show my current address, is that ok?</h3>
                  <p>Yes! Your address on your photo ID does not need to match your lease agreement. We do need a copy of your photo ID to verify we are talking to you!</p>
                </div>
                <div>
                  <h3 className="font-semibold">Can I use your service if another company has already reported my address?</h3>
                  <p>No! TransUnion, Experian & Experian only allows an address to be reported once on your credit report. If you have another company already reporting the address you want to enroll with us, we will not be able to report it for you. Please note that if you do enroll and it turns out you have another company reporting the same address, we will be unable to issue any refunds.</p>
                </div>
                <div>
                  <h3 className="font-semibold">Can you report rent for my commercial address?</h3>
                  <p>3rd Party Rent Reporting agencies such as ourselves are only authorized to report Residential Leases - not commercial leases (even if the commercial lease is in your personal name).</p>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="credit-bureaus">
            <AccordionTrigger className="text-lg font-semibold text-[#1D3557]">Credit Bureaus</AccordionTrigger>
            <AccordionContent>
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold">Do you report to all three credit bureaus?</h3>
                  <p>Yes! We report to TransUnion and Experian. Experian has a slightly different reporting process than TransUnion. After we complete your account for TransUnion, you will receive a text message and email letting you know that you now have the opportunity to start the Experian process.</p>
                </div>
                <div>
                  <h3 className="font-semibold">What are the requirements to report my rent payments to Experian?</h3>
                  <ul className="list-disc list-inside space-y-2">
                    <li>Pay your rent from your bank, savings, or credit card account. Experian is not currently accepting rent payments made with cash or money orders.</li>
                    <li>If you have a spouse or roommate, the entire rent payment must only come out of one person's bank, savings, or credit card account.</li>
                    <li>Experian requires you to connect your bank, savings, or credit card account that you pay your rent with in our secure tenant portal using Plaid.</li>
                    <li>After you connect your account, you will receive a text message and email letting you know that your account has downloaded your transactions.</li>
                    <li>Once your transactions are downloaded, you will be able to select your rent payments and apply them to the appropriate month.</li>
                    <li>After you have applied all of your rent payments, you will verify the information, and then submit it to our team.</li>
                    <li>Your landlord will also receive a copy of the verification of rent.</li>
                    <li>To complete the Experian process you will need to do it on a laptop or desktop computer. (Mobile coming soon).</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold">Experian Reporting Timeline:</h3>
                  <p>If the above steps are completed by the 15th of the month, then your new Experian account will be reported on the 5th of the next month!</p>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="credit-score">
            <AccordionTrigger className="text-lg font-semibold text-[#1D3557]">Credit Score and Reports</AccordionTrigger>
            <AccordionContent>
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold">How much will my credit score increase?</h3>
                  <p>No two credit profiles are identical. However, we have generally seen a range of 7 to 120 point increases. For someone that has not established credit, it is possible for them to get a score above 640 fairly quickly. On the other side of the spectrum, if someone has established a strong credit profile, with all on-time payments, they will probably see a much lower impact to their credit score – as with adding any new tradeline.</p>
                </div>
                <div>
                  <h3 className="font-semibold">Do you pull my credit and cause a new inquiry?</h3>
                  <p>No! We do not pull your credit and cause a new inquiry! This is another benefit of having your rent payments reported! You can create a new account without any inquiries! Every inquiry on your credit report can reduce your score.</p>
                </div>
                <div>
                  <h3 className="font-semibold">What if I do not see my score increase?</h3>
                  <p>Generally our customers always see some sort of score increase. Some points to keep in mind:</p>
                  <ul className="list-disc list-inside space-y-2">
                    <li>Are you looking at the correct report? All of our rental accounts are reported directly to TransUnion and Experian. Please make sure you are looking at your TransUnion or Experian report.</li>
                    <li>If you see your new account, but no score increase it is possible that the 3rd party credit report provider you are using has updated your report, but not your score. Sometimes it will take them an additional week or so to fully update your credit report.</li>
                    <li>Did you just add ongoing reporting? If so, it may take a bit longer to see a score increase since the credit bureau needs to see continued on-time monthly payments. If you have lived at your property longer, you should consider adding the past reporting option!</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold">Does my account show closed if I only have you report my past rent payments?</h3>
                  <p>Yes – Your account will show closed if you only enroll in the past 12 or 24 month reporting. This still has the benefit of creating a great past history for you and building your credit profile. To show the account as open, we are required to verify your ongoing monthly payments with your landlord. Most of our renters experience the best increase in their scores when we report past history along with current ongoing reporting!</p>
                </div>
                <div>
                  <h3 className="font-semibold">How soon will my new rental account show on my credit report?</h3>
                  <p>We report twice a month to TransUnion on the 5th and 15th. After reporting, TransUnion typically has your new account active within 5-7 business days. For Experian - if we have received your rent verification by the 15th of the month, then your new Experian account will be reported on the 5th of the next month. Experian will typically have your new account active within 5-7 business days.</p>
                </div>
                <div>
                  <h3 className="font-semibold">My rental account appeared but now it's gone – What happened?</h3>
                  <p>While this is very rare, in some situations if you have a "freeze" or "monitoring" on your account, this can cause your new rental account to be deleted. If this happens, please reach out to the company that you hired to "freeze" or "monitor" your account and ask them to allow your new rental account to appear.</p>
                </div>
                <div>
                  <h3 className="font-semibold">Do you guys repair my credit?</h3>
                  <p>No - we are not a credit repair company. We are a third-party credit reporter. Our job is to verify your payments and report that information to the credit bureau.</p>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>

        <section className="mt-12 text-center">
          <h2 className="text-2xl font-semibold mb-4 text-[#1D3557]">Still Have Questions?</h2>
          <p className="mb-4">If you couldn't find the answer you were looking for, please don't hesitate to reach out to our support team.</p>
          <Button asChild>
            <Link href="/contact" className="bg-[#1D3557] text-white hover:bg-[#457B9D] px-8 py-3 rounded-md transition-colors">
              Contact Support
            </Link>
          </Button>
        </section>
      </main>
    </div>
  )
}

