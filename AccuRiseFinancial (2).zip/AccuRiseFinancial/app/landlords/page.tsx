import Link from 'next/link'
import { Button } from "@/components/ui/button"

export default function LandlordsPage() {
  return (
    <main className="flex-grow">
      <section className="bg-[#1D3557] text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Boost Your Tenants' Credit Scores</h1>
          <p className="text-xl mb-8">Improve tenant creditworthiness and reduce turnover by reporting rent payments.</p>
          <Button asChild>
            <Link href="/landlord-portal" className="bg-[#F4A261] text-[#1D3557] hover:bg-[#E76F51] px-8 py-3 rounded-md transition-colors">
              Join Landlord Portal
            </Link>
          </Button>
        </div>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-[#1D3557]">How It Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-4">Step 1: Sign Up</h3>
              <p>Sign up for the Landlord Portal.</p>
            </div>
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-4">Step 2: Enroll Tenants</h3>
              <p>Enroll tenants and submit rent data.</p>
            </div>
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-4">Step 3: We Report</h3>
              <p>We report to TransUnion and Experian.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-[#F1FAEE] py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-[#1D3557]">Pricing</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="text-center p-6 bg-white rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-4">1-9 Units</h3>
              <p className="text-2xl font-bold mb-4">$49/unit/year</p>
              <p>For the first 12 months or until a new tenant moves in</p>
              <p className="mt-2">Renewal: $25/unit/year</p>
            </div>
            <div className="text-center p-6 bg-white rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-4">10+ Units</h3>
              <p className="text-2xl font-bold mb-4">$2.50/unit/month</p>
              <p>Ideal for property management companies</p>
              <p className="mt-2">Free initial batch (minimum 10 units)</p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-8 text-[#1D3557]">Ready to Empower Your Tenants?</h2>
          <Button asChild>
            <Link href="/landlord-portal" className="bg-[#F4A261] text-[#1D3557] hover:bg-[#E76F51] px-8 py-3 rounded-md transition-colors">
              Enroll Your Property Today
            </Link>
          </Button>
        </div>
      </section>
    </main>
  )
}

