import { NextResponse } from 'next/server'
import Airtable from 'airtable'

// Initialize Airtable
const base = new Airtable({ apiKey: process.env.AIRTABLE_API_KEY }).base(process.env.AIRTABLE_BASE_ID!)

export async function POST(req: Request) {
  if (req.method === 'POST') {
    try {
      const data = await req.json()

      // Create a record in Airtable
      const record = await base('Landlords').create([
        {
          fields: {
            'Company Name': data.companyName,
            'First Name': data.firstName,
            'Last Name': data.lastName,
            'Email': data.email,
            'Phone': data.phone,
            'Type': data.type,
            'Website': data.website,
          }
        }
      ])

      return NextResponse.json({ success: true, id: record[0].id })
    } catch (error) {
      console.error('Error submitting to Airtable:', error)
      return NextResponse.json({ success: false, error: 'Failed to submit form' }, { status: 500 })
    }
  } else {
    return NextResponse.json({ success: false, error: 'Method not allowed' }, { status: 405 })
  }
}

