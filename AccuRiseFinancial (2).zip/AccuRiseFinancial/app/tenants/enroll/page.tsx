"use client"

import * as React from "react"
import { useRef } from "react"
import { ChevronRight, ChevronLeft } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/components/ui/use-toast"
import { useSearchParams } from 'next/navigation'

interface FormData {
  // Personal Information
  firstName: string
  lastName: string
  phone: string
  email: string
  dateOfBirth: string
  ssn: string
  
  // Address Information
  address: string
  city: string
  state: string
  zip: string
  
  // Lease Information
  leaseStartDate: string
  leaseEndDate: string
  monthlyRent: string
  
  // Landlord Information
  landlordEmail: string
  
  // Reporting Options
  reportingOption: string
  
  // Payment Information
  cardNumber: string
  expiryDate: string
  cvv: string
  agreeToTerms: boolean
}

const PRICING = {
  enrollmentFee: 0,
  monthlySubscription: 9.95,
  pastReporting: 84.00
}

export default function EnrollmentWizard() {
  const [currentStep, setCurrentStep] = React.useState(1)
  const searchParams = useSearchParams()
  const initialPlanRef = useRef(searchParams.get('plan') || 'ongoing')
  const [formData, setFormData] = React.useState<FormData>({
    firstName: "",
    lastName: "",
    phone: "",
    email: "",
    dateOfBirth: "",
    ssn: "",
    address: "",
    city: "",
    state: "",
    zip: "",
    leaseStartDate: "",
    leaseEndDate: "",
    monthlyRent: "",
    landlordEmail: "",
    reportingOption: initialPlanRef.current,
    cardNumber: "",
    expiryDate: "",
    cvv: "",
    agreeToTerms: false
  })
  const { toast } = useToast()

  React.useEffect(() => {
    const planParam = searchParams.get('plan')
    if (planParam && planParam !== formData.reportingOption) {
      setFormData(prevData => ({
        ...prevData,
        reportingOption: planParam
      }))
    }
  }, [searchParams])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
  }

  const handleNext = () => {
    if (currentStep < 4) {
      setCurrentStep(prev => prev + 1)
    } else {
      handleSubmit()
    }
  }

  const handlePrevious = () => {
    setCurrentStep(prev => Math.max(prev - 1, 1))
  }

  const calculateTotal = () => {
    let total = PRICING.enrollmentFee
    if (formData.reportingOption === "ongoing" || formData.reportingOption === "monthly") {
      total += PRICING.monthlySubscription
    }
    if (formData.reportingOption === "past" || formData.reportingOption === "past-12" || formData.reportingOption === "past-24") {
      total += PRICING.pastReporting
    }
    return total.toFixed(2)
  }

  const handleSubmit = async () => {
    // Here you would typically send the data to your backend
    console.log("Form submitted:", formData)
    toast({
      title: "Enrollment Submitted",
      description: "Your enrollment has been received. We'll contact you soon to complete the process.",
    })
    // Redirect or show a success message
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <Card className="max-w-3xl mx-auto">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold text-[#1D3557]">
              Rent Reporting Enrollment
            </CardTitle>
          </CardHeader>
          <CardContent>
            {/* Progress Steps */}
            <div className="mb-8">
              <div className="relative">
                <div className="absolute left-0 top-1/2 h-0.5 w-full bg-gray-200 transform -translate-y-1/2" />
                <div 
                  className="absolute left-0 top-1/2 h-0.5 bg-green-500 transform -translate-y-1/2 transition-all duration-300"
                  style={{ width: `${(currentStep - 1) * 33.33}%` }}
                />
                <div className="relative flex justify-between">
                  {[
                    "Your Info",
                    "Lease Details",
                    "Reporting Options",
                    "Payment"
                  ].map((step, index) => (
                    <div
                      key={index}
                      className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        index + 1 <= currentStep ? 'bg-green-500 text-white' : 'bg-gray-200'
                      }`}
                    >
                      {index + 1}
                    </div>
                  ))}
                </div>
              </div>
              <div className="flex justify-between mt-2 text-sm">
                <span>Your Info</span>
                <span>Lease Details</span>
                <span>Reporting Options</span>
                <span>Payment</span>
              </div>
            </div>

            {/* Step 1: Personal Information */}
            {currentStep === 1 && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="firstName">First Name</Label>
                    <Input
                      id="firstName"
                      name="firstName"
                      value={formData.firstName}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input
                      id="lastName"
                      name="lastName"
                      value={formData.lastName}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="phone">Phone</Label>
                    <Input
                      id="phone"
                      name="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="dateOfBirth">Date of Birth</Label>
                  <Input
                    id="dateOfBirth"
                    name="dateOfBirth"
                    type="date"
                    value={formData.dateOfBirth}
                    onChange={handleInputChange}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="ssn">Social Security Number</Label>
                  <Input
                    id="ssn"
                    name="ssn"
                    type="password"
                    value={formData.ssn}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>
            )}

            {/* Step 2: Lease Information */}
            {currentStep === 2 && (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="address">Address</Label>
                  <Input
                    id="address"
                    name="address"
                    value={formData.address}
                    onChange={handleInputChange}
                    required
                  />
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="city">City</Label>
                    <Input
                      id="city"
                      name="city"
                      value={formData.city}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="state">State</Label>
                    <Input
                      id="state"
                      name="state"
                      value={formData.state}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="zip">ZIP Code</Label>
                    <Input
                      id="zip"
                      name="zip"
                      value={formData.zip}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="leaseStartDate">Lease Start Date</Label>
                    <Input
                      id="leaseStartDate"
                      name="leaseStartDate"
                      type="date"
                      value={formData.leaseStartDate}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="leaseEndDate">Lease End Date</Label>
                    <Input
                      id="leaseEndDate"
                      name="leaseEndDate"
                      type="date"
                      value={formData.leaseEndDate}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="monthlyRent">Monthly Rent Amount</Label>
                  <Input
                    id="monthlyRent"
                    name="monthlyRent"
                    type="number"
                    value={formData.monthlyRent}
                    onChange={handleInputChange}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="landlordEmail">Landlord's Email</Label>
                  <Input
                    id="landlordEmail"
                    name="landlordEmail"
                    type="email"
                    value={formData.landlordEmail}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>
            )}

            {/* Step 3: Reporting Options */}
            {currentStep === 3 && (
              <div className="space-y-4">
                <div>
                  <Label>Select Reporting Option</Label>
                  <RadioGroup
                    defaultValue={formData.reportingOption}
                    onValueChange={(value) => setFormData({...formData, reportingOption: value})}
                  >
                    <div className="flex items-center space-x-2 p-4 border rounded-lg mb-2">
                      <RadioGroupItem value="ongoing" id="ongoing" />
                      <Label htmlFor="ongoing">
                        <div className="font-semibold">Ongoing Monthly Reporting</div>
                        <div className="text-sm text-gray-500">${PRICING.monthlySubscription}/month</div>
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2 p-4 border rounded-lg">
                      <RadioGroupItem value="past" id="past" />
                      <Label htmlFor="past">
                        <div className="font-semibold">Past 12 Months Reporting</div>
                        <div className="text-sm text-gray-500">${PRICING.pastReporting} one-time fee</div>
                      </Label>
                    </div>
                  </RadioGroup>
                </div>
              </div>
            )}

            {/* Step 4: Payment */}
            {currentStep === 4 && (
              <div className="space-y-6">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h3 className="font-semibold mb-4">Enrollment Summary</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Enrollment Setup Fee</span>
                      <span>${PRICING.enrollmentFee.toFixed(2)}</span>
                    </div>
                    {(formData.reportingOption === "ongoing" || formData.reportingOption === "monthly") && (
                      <div className="flex justify-between">
                        <span>Monthly Subscription</span>
                        <span>${PRICING.monthlySubscription.toFixed(2)}</span>
                      </div>
                    )}
                    {(formData.reportingOption === "past" || formData.reportingOption === "past-12" || formData.reportingOption === "past-24") && (
                      <div className="flex justify-between">
                        <span>Past 12 Months Reporting</span>
                        <span>${PRICING.pastReporting.toFixed(2)}</span>
                      </div>
                    )}
                    <div className="border-t pt-2 font-semibold flex justify-between">
                      <span>Total</span>
                      <span>${calculateTotal()}</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <Label htmlFor="cardNumber">Card Number</Label>
                    <Input
                      id="cardNumber"
                      name="cardNumber"
                      value={formData.cardNumber}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="expiryDate">Expiry Date</Label>
                      <Input
                        id="expiryDate"
                        name="expiryDate"
                        placeholder="MM/YY"
                        value={formData.expiryDate}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="cvv">CVV</Label>
                      <Input
                        id="cvv"
                        name="cvv"
                        value={formData.cvv}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="terms"
                    checked={formData.agreeToTerms}
                    onCheckedChange={(checked) => 
                      setFormData({...formData, agreeToTerms: checked as boolean})
                    }
                  />
                  <Label htmlFor="terms" className="text-sm">
                    I agree to the Terms of Service and Privacy Policy
                  </Label>
                </div>
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex justify-between mt-8">
              <Button
                variant="outline"
                onClick={handlePrevious}
                disabled={currentStep === 1}
              >
                <ChevronLeft className="mr-2 h-4 w-4" />
                Previous
              </Button>
              <Button
                onClick={handleNext}
                disabled={currentStep === 4 && !formData.agreeToTerms}
              >
                {currentStep === 4 ? 'Complete Enrollment' : 'Next'}
                <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

