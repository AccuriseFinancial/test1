import Link from 'next/link'
import { Button } from "@/components/ui/button"

export default function TenantsPage() {
  return (
    <main className="flex-grow">
      <section className="bg-[#1D3557] text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Boost Your Credit Score with Rent Reporting</h1>
          <p className="text-xl mb-8">Report your past and ongoing rent payments to the three major credit bureaus.</p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button asChild>
              <Link href="/tenants/pricing" className="bg-[#F4A261] text-[#1D3557] hover:bg-[#E76F51] px-8 py-3 rounded-md transition-colors">
                View Pricing Plans
              </Link>
            </Button>
            <Button asChild variant="outline">
              <Link href="/tenants/enroll" className="bg-transparent text-white border-2 border-white hover:bg-[#457B9D] px-8 py-3 rounded-md transition-colors">
                Start Enrolling Now
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-[#1D3557]">How It Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-4">Step 1: Enroll</h3>
              <p>Sign up and provide personal and rental history.</p>
            </div>
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-4">Step 2: Verify Rent</h3>
              <p>We contact your landlord to confirm payments.</p>
            </div>
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-4">Step 3: Get Reported</h3>
              <p>Rent Payments Reported to TransUnion and Experian.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-[#F1FAEE] py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-[#1D3557]">Benefits of Rent Reporting</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-4">Credit Score Boost</h3>
              <p>Potential to increase your credit score by up to 100 points.</p>
            </div>
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-4">Build Credit History</h3>
              <p>Establish or improve your credit profile without taking on new debt.</p>
            </div>
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-4">Better Loan Terms</h3>
              <p>Qualify for better interest rates on future loans or credit cards.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-8 text-[#1D3557]">Ready to Boost Your Credit?</h2>
          <Button asChild>
            <Link href="/tenants/pricing" className="bg-[#F4A261] text-[#1D3557] hover:bg-[#E76F51] px-8 py-3 rounded-md transition-colors">
              View Pricing Plans
            </Link>
          </Button>
        </div>
      </section>
    </main>
  )
}

