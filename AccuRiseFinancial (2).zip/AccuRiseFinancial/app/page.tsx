import Link from 'next/link'
import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <main className="flex-grow">

      <section className="bg-[#1D3557] text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Building Credit with Every Rent Payment</h1>
          <p className="text-xl mb-8">Improve your credit score by reporting your rent to TransUnion and Experian.</p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button asChild>
              <Link href="/tenants" className="bg-[#F4A261] text-[#1D3557] hover:bg-[#E76F51] px-8 py-3 rounded-md transition-colors">
                I'm a Tenant
              </Link>
            </Button>
            <Button asChild variant="outline">
              <Link href="/landlords" className="bg-transparent text-white border-2 border-white hover:bg-[#457B9D] px-8 py-3 rounded-md transition-colors">
                I'm a Landlord
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-[#1D3557]">How It Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-4">Sign Up</h3>
              <p>Provide tenant or landlord details.</p>
            </div>
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-4">Verify Rent</h3>
              <p>Upload documents and confirm with your landlord.</p>
            </div>
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-4">Get Reported</h3>
              <p>We report your rent payments to credit bureaus.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-[#F1FAEE] py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-[#1D3557]">Why Choose AccuRise Financial?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-4">Credit Score Improvement</h3>
              <p>Potential to increase up to 100 points</p>
            </div>
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-4">Comprehensive Reporting</h3>
              <p>Report both past and ongoing rent payments</p>
            </div>
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-4">No Credit Inquiries</h3>
              <p>Build credit without affecting your score</p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-8 text-[#1D3557]">Ready to Get Started?</h2>
          <Button asChild>
            <Link href="/tenants/enroll" className="bg-[#F4A261] text-[#1D3557] hover:bg-[#E76F51] px-8 py-3 rounded-md transition-colors">
              Enroll Now
            </Link>
          </Button>
        </div>
      </section>
    </main>
  )
}

