import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import Link from 'next/link'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'AccuRise Financial',
  description: 'Building credit with every rent payment',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <header>
          <div className="bg-[#1D3557] text-white py-2 text-center">
            <div className="container mx-auto">
              <p className="text-sm">Now Reporting to TransUnion and Experian! (Terms Apply)</p>
            </div>
          </div>
          <nav className="bg-[#457B9D] text-white py-4">
            <div className="container mx-auto px-4">
              <ul className="flex justify-center space-x-6">
                <li><Link href="/tenants" className="hover:text-[#F4A261] transition-colors">Tenants</Link></li>
                <li><Link href="/landlords" className="hover:text-[#F4A261] transition-colors">Landlords</Link></li>
                <li><Link href="/faqs" className="hover:text-[#F4A261] transition-colors">FAQs</Link></li>
                <li><Link href="/about" className="hover:text-[#F4A261] transition-colors">About</Link></li>
                <li><Link href="/contact" className="hover:text-[#F4A261] transition-colors">Contact</Link></li>
              </ul>
            </div>
          </nav>
        </header>
        {children}
        <footer className="bg-[#1D3557] text-white py-6">
          <div className="container mx-auto px-4">
            <div className="flex flex-wrap justify-between">
              <div className="w-full md:w-1/3 mb-4 md:mb-0">
                <h3 className="text-lg font-semibold mb-2">AccuRise Financial</h3>
                <p className="text-sm">Empowering financial futures through innovative rent reporting.</p>
              </div>
              <div className="w-full md:w-1/3 mb-4 md:mb-0">
                <h3 className="text-lg font-semibold mb-2">Quick Links</h3>
                <ul className="text-sm">
                  <li><a href="/tenants" className="hover:text-[#F4A261]">Tenants</a></li>
                  <li><a href="/landlords" className="hover:text-[#F4A261]">Landlords</a></li>
                  <li><a href="/faqs" className="hover:text-[#F4A261]">FAQs</a></li>
                </ul>
              </div>
              <div className="w-full md:w-1/3 text-right">
                <p className="text-sm">&copy; 2023 AccuRise Financial. All rights reserved.</p>
                <div className="mt-2">
                  <a href="/privacy-policy" className="text-sm hover:text-[#F4A261] mr-4">Privacy Policy</a>
                  <a href="/terms-and-conditions" className="text-sm hover:text-[#F4A261]">Terms and Conditions</a>
                </div>
              </div>
            </div>
          </div>
        </footer>
      </body>
    </html>
  )
}

