import Link from 'next/link'
import { Button } from "@/components/ui/button"

export default function AboutPage() {
  return (
    <div className="flex flex-col min-h-screen bg-[#F1FAEE]">
      <main className="flex-grow container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8 text-[#1D3557] text-center">About AccuRise Financial</h1>

        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4 text-[#1D3557]">Our Mission</h2>
          <p className="mb-4">
            At AccuRise Financial, we are dedicated to empowering military members, veterans, and low-income families to build better financial futures. Our mission is to make rent payment reporting accessible and impactful, helping individuals improve their credit scores and achieve their financial goals.
          </p>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4 text-[#1D3557]">Our Story</h2>
          <p className="mb-4">
            Founded in 2016, AccuRise Financial was born out of a desire to address a significant gap in the credit reporting system. We recognized that millions of responsible renters were not getting credit for their largest monthly payment. Our team set out to change this, developing a platform that allows rent payments to be reported to major credit bureaus, helping renters build their credit profiles.
          </p>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4 text-[#1D3557]">Our Core Values</h2>
          <ul className="list-disc list-inside space-y-2">
            <li><span className="font-semibold">Service & Impact:</span> We are committed to supporting our communities and making a positive difference in people's lives.</li>
            <li><span className="font-semibold">Integrity:</span> We uphold the highest standards of ethical behavior and transparent practices in all our operations.</li>
            <li><span className="font-semibold">Accessibility:</span> We strive to make our services inclusive and affordable, ensuring that everyone has the opportunity to build their credit.</li>
          </ul>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4 text-[#1D3557]">Social Responsibility</h2>
          <p className="mb-4">
            We are proud of our commitment to community outreach and our partnerships with veteran organizations. Through these initiatives, we aim to provide financial education and support to those who have served our country.
          </p>
        </section>

        <section className="text-center">
          <h2 className="text-2xl font-semibold mb-4 text-[#1D3557]">Join Us in Our Mission</h2>
          <p className="mb-6">
            Whether you're a renter looking to build your credit or a property owner wanting to offer this valuable service to your tenants, we invite you to join us in our mission to create a more inclusive credit reporting system.
          </p>
          <Button asChild>
            <Link href="/enroll" className="bg-[#F4A261] text-[#1D3557] hover:bg-[#E76F51] px-8 py-3 rounded-md transition-colors">
              Get Started Today
            </Link>
          </Button>
        </section>
      </main>
    </div>
  )
}

