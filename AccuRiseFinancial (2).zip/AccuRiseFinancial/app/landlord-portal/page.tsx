"use client"

import React from 'react'
import Link from 'next/link'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"

export default function LandlordPortal() {
  const [formData, setFormData] = React.useState({
    companyName: "",
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    type: "",
    website: ""
  })

  const { toast } = useToast()

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
  }

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    try {
      const response = await fetch('/api/submit-landlord', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      })

      if (!response.ok) {
        throw new Error('Failed to submit form')
      }

      toast({
        title: "Form Submitted",
        description: "You should receive your Landlord Portal login information shortly.",
      })

      // Reset form
      setFormData({
        companyName: "",
        firstName: "",
        lastName: "",
        email: "",
        phone: "",
        type: "",
        website: ""
      })
    } catch (error) {
      toast({
        title: "Submission Failed",
        description: "There was an error submitting your form. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <header className="bg-[#1D3557] text-white py-4">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold text-center">Landlord Portal</h1>
        </div>
      </header>

      <main className="flex-grow container mx-auto px-4 py-8">
        <Card className="max-w-3xl mx-auto">
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-center text-[#1D3557]">Sign Up for Landlord Portal</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="companyName">Company Name</Label>
                <Input
                  id="companyName"
                  name="companyName"
                  value={formData.companyName}
                  onChange={handleInputChange}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="firstName">First Name *</Label>
                  <Input
                    id="firstName"
                    name="firstName"
                    value={formData.firstName}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastName">Last Name *</Label>
                  <Input
                    id="lastName"
                    name="lastName"
                    value={formData.lastName}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone *</Label>
                  <Input
                    id="phone"
                    name="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="type">Type *</Label>
                <Select 
                  onValueChange={(value) => setFormData({...formData, type: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="individual">Individual Landlord</SelectItem>
                    <SelectItem value="company">Property Management Company</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="website">Website</Label>
                <Input
                  id="website"
                  name="website"
                  type="url"
                  value={formData.website}
                  onChange={handleInputChange}
                />
              </div>


              <div className="flex justify-center mt-6">
                <Button type="submit" className="bg-[#1D3557] hover:bg-[#152A45] text-white px-8">
                  Submit
                </Button>
              </div>
            </form>

            <p className="mt-6 text-sm text-gray-600">
              After submitting the form, you should receive your Landlord Portal login information. If you don't receive your login information email after 10 minutes and you have checked your spam folder, please contact our office at 872-225-5259 (Phone Support Hours Monday – Saturday 9:00am to 5:00pm CST) or email us at empower@accurisefinancial.com.
            </p>
          </CardContent>
        </Card>
      </main>

      <footer className="bg-[#1D3557] text-white py-4 mt-auto">
        <div className="container mx-auto px-4">
          <div className="text-center mb-4">
            <p>Phone: 872-225-5259 | Email: empower@accurisefinancial.com</p>
            <p>Support Hours: Monday-Saturday: 9:00am to 5:00pm CST</p>
          </div>
          <p className="text-center text-sm">&copy; {new Date().getFullYear()} Accurise Financial</p>
        </div>
      </footer>
    </div>
  )
}

